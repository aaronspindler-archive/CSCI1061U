float average3(float a, float b, float c);
void average(const float* arr, int arr_size, float& ave, float& sd);
